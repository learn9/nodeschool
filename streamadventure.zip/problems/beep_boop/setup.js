module.exports = function () {
    return { args: [], stdin: null };
};
